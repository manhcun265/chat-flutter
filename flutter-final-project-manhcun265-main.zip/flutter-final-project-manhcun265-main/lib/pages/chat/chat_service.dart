import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_project/pages/models/mess.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  //xem người dùng bằng stream
  /*
  {email:123456@gmail.com
  id:......

  }
  */
  Stream<List<Map<String, dynamic>>> getUsersStream() {
    return _firestore.collection("Users").snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        final user = doc.data();
        return user;
      }).toList();
    });
  }

  //gui tin nhan
  Future<void> sendMessage(String receiverID, message) async {
    final String currentUserID =
        _auth.currentUser!.uid; // lay thong tin nguoi nhan
    final String currentUserEmail = _auth.currentUser!.email!;
    final Timestamp timestamp = Timestamp.now();
    // tạo tin nhắn
    Message newMess = Message(
        sendId: currentUserID,
        sendEmail: currentUserEmail,
        receiverID: receiverID,
        message: message,
        timestamp: timestamp);
    // tao id phong chat
    List<String> Ids = [
      currentUserID,
      receiverID
    ]; // id nguowif dungf vaf id nguowi nhan
    Ids.sort(); // 1 phong chat se co 2 nguoi
    String ChatRoomId = Ids.join('_');
//them tin nhan vao fire base
    await _firestore
        .collection("chat_Room")
        .doc(ChatRoomId)
        .collection("message")
        .add(newMess.toMap());
  } // lay tin nhan

  Stream<QuerySnapshot> getMessages(String userID, otherId) {
    List<String> ids = [userID, otherId];
    ids.sort();
    String ChatRoomIds = ids.join('_');
    return _firestore
        .collection("chat_Room")
        .doc(ChatRoomIds)
        .collection("message")
        .orderBy("timestamp", descending: false)
        .snapshots();
  }
   // Phương thức xóa một người dùng và toàn bộ dữ liệu liên quan
  Future<void> deleteFriend(String friendId) async {
    try {
      // Xóa tài liệu người dùng khỏi bộ sưu tập Users
      await _firestore.collection('Users').doc(friendId).delete();

      // Xóa các phòng chat và tin nhắn liên quan
      final chatRooms = await _firestore
          .collection('chat_Room')
          .where('members', arrayContains: friendId)
          .get();

      for (var chatRoom in chatRooms.docs) {
        await _firestore
            .collection('chat_Room')
            .doc(chatRoom.id)
            .collection('message')
            .get()
            .then((snapshot) {
          for (var doc in snapshot.docs) {
            doc.reference.delete();
          }
        });
        await _firestore.collection('chat_Room').doc(chatRoom.id).delete();
      }

      print('Đã xóa bạn bè và các dữ liệu liên quan.');
    } catch (e) {
      print('Lỗi khi xóa bạn bè: $e');
    }
  }
}

