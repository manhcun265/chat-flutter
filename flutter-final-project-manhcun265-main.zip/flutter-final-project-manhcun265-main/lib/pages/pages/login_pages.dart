import 'package:flutter/material.dart';
import 'package:flutter_project/pages/authgates/auth_service.dart';
import 'package:flutter_project/pages/themes/button.dart';
import 'package:flutter_project/pages/themes/text_field.dart';

class LoginPage extends StatelessWidget {
  LoginPage({super.key, required this.onTap});

  final void Function()? onTap;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passWordController = TextEditingController();
  //ontap

  //auth service
  void Login(BuildContext context) async {
    final authService = AuthService();
    try {
      await authService.signInWithEmailAndPassword(
          _emailController.text, _passWordController.text);
    } catch (e) {
      showDialog(
          context: context,
          builder: (context) => AlertDialog(
                title: Text(e.toString()),
              ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.message,
              size: 60,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(
              height: 50,
            ),
            //text
            Text(
              "Chào mừng bạn đến với trang chat",
              style: TextStyle(
                  color: Theme.of(context).colorScheme.primary, fontSize: 16),
            ),
            const SizedBox(
              height: 25,
            ),
            // email
            Mytextfield(
              hintText: "Vui lòng nhập email",
              prefixIcon: const Icon(Icons.email),
              obscureText: false,
              controller: _emailController,
            ),
            const SizedBox(
              height: 10,
            ),
            //password
            Mytextfield(
              hintText: "Vui lòng nhập mật khẩu",
              prefixIcon: const Icon(Icons.lock),
              obscureText: true,
              controller: _passWordController,
            ),
            const SizedBox(
              height: 10,
            ),
            //button
            isButton(
              text: "Login",
              onTap: () => Login(context),
            ),
            const SizedBox(
              height: 25,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Đăng kí ngay - "),
                GestureDetector(
                  onTap: onTap,
                  child: const Text(
                    " DĂNG KÝ",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.greenAccent,
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
