import 'package:flutter/material.dart';
import 'package:flutter_project/pages/authgates/auth_service.dart';
import 'package:flutter_project/pages/themes/button.dart';
import 'package:flutter_project/pages/themes/text_field.dart';

class RegisterPage extends StatelessWidget {
  RegisterPage({super.key, required this.onTap});
  final void Function()? onTap;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passWordController = TextEditingController();
  final TextEditingController _confimpassWordController =
      TextEditingController();

  void Register(BuildContext context) {
    final auth = AuthService();
    // xac nhan mat khau
    if (_passWordController.text == _confimpassWordController.text) {
      try {
        auth.signUpWithEmailAndPassword(
            _emailController.text, _passWordController.text);
      } catch (e) {
        showDialog(
            context: context,
            builder: (context) => AlertDialog(
                  title: Text(e.toString()),
                ));
      }
    } else {
      showDialog(
          context: context,
          builder: (context) => const AlertDialog(
                title: Text('Mật khẩu không khớp'),
              ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.message,
              size: 60,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(
              height: 50,
            ),
            //text
            Text(
              "Chào mừng bạn đến với trang chat hãy đăng ký nào",
              style: TextStyle(
                  color: Theme.of(context).colorScheme.primary, fontSize: 16),
            ),
            const SizedBox(
              height: 25,
            ),

            // email
            Mytextfield(
              hintText: "VUi lòng nhập email",
              prefixIcon: const Icon(Icons.email),
              obscureText: false,
              controller: _emailController,
            ),
            const SizedBox(
              height: 10,
            ),

            //password
            Mytextfield(
              hintText: "Vui lòng nhập mật khẩu",
              prefixIcon: const Icon(Icons.lock),
              obscureText: true,
              controller: _passWordController,
            ),

            const SizedBox(
              height: 10,
            ),
            //confimpassword
            Mytextfield(
              hintText: "Xác nhận lại mật khẩu ",
              prefixIcon: const Icon(Icons.lock_clock_outlined),
              obscureText: true,
              controller: _confimpassWordController,
            ),
            const SizedBox(
              height: 10,
            ),
            //button
            isButton(
              text: "Register",
              onTap: () => Register(context),
            ),
            const SizedBox(
              height: 25,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Bạn đã có mật khẩu ? "),
                GestureDetector(
                  onTap: onTap,
                  child: const Text(
                    " Login",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.greenAccent,
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
