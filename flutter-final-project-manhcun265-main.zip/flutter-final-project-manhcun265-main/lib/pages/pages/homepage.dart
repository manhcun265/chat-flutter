import 'package:flutter/material.dart';
import 'package:flutter_project/pages/authgates/auth_service.dart';
import 'package:flutter_project/pages/chat/chat_service.dart';
import 'package:flutter_project/pages/pages/chat_page.dart';
import 'package:flutter_project/pages/themes/drawer.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  final ChatService _chatService = ChatService();
  final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Home page'),
        backgroundColor: const Color.fromARGB(255, 255, 137, 3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      drawer: const Drawerwidget(),
      body: _UserList(),
    );
  }

  // Tạo danh sách người dùng
  Widget _UserList() => StreamBuilder(
        stream: _chatService.getUsersStream(),
        builder: (context, snapshot) {
          // Báo lỗi
          if (snapshot.hasError) {
            return const Text("ERROR");
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Text("LOADING....");
          }
          return ListView(
            children: snapshot.data!
                .map<Widget>((userData) => _UserListItem(userData, context))
                .toList(),
          );
        },
      );

  // Hiển thị danh sách bạn bè
  Widget _UserListItem(Map<String, dynamic> userData, BuildContext context) {
    if (userData["email"] != _authService.getCurrentUser()) {
      return ListTile(
        title: Text(userData["email"]),
        trailing: IconButton(
          icon: Icon(Icons.delete),
          onPressed: () async {
            await _chatService.deleteFriend(userData["uid"]);
          },
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatPage(
                receiverEmail: userData["email"],
                receiverID: userData["uid"],
              ),
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }
}

