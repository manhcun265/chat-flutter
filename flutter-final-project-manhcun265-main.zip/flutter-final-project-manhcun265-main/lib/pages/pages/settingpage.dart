import 'package:flutter/material.dart';
import 'package:flutter_project/pages/themes/theme_provider.dart';
import 'package:provider/provider.dart';

class SettingPage extends StatelessWidget {
  const SettingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      appBar: AppBar(
        title: const Text("Setting page"),
        backgroundColor: const Color.fromARGB(255, 255, 137, 3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondary,
            borderRadius: BorderRadius.circular(15)),
        margin: const EdgeInsets.all(25),
        padding: const EdgeInsets.all(15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("dark mode"),
            Switch(
              value:
                  Provider.of<ThemeProvider>(context, listen: false).isdarkmode,
              onChanged: (value) =>
                  Provider.of<ThemeProvider>(context, listen: false).tryTheme(),
            ),
          ],
        ),
      ),
    );
  }
}
