import 'package:flutter/material.dart';
import 'package:flutter_project/pages/themes/theme_provider.dart';
import 'package:provider/provider.dart';

class ChatBubble extends StatelessWidget {
  final String message;
  final bool isCurrentUser;

  const ChatBubble({
    super.key,
    required this.message,
    required this.isCurrentUser,
  });

  @override
  Widget build(BuildContext context) {
    // doi mau chat khi ow hai che doj light va dark
    bool isdarkmode =
        Provider.of<ThemeProvider>(context, listen: false).isdarkmode;
    return Container(
      decoration: BoxDecoration(
        color: isCurrentUser
            ? (isdarkmode ? Colors.green.shade600 : Colors.green.shade600)
            : (isdarkmode
                ? Colors.grey.shade800
                : const Color.fromARGB(255, 236, 237, 238)),
        borderRadius: BorderRadius.circular(15),
      ),
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 25),
      child: Text(
        message,
        style: TextStyle(
            color: isCurrentUser
                ? Colors.white
                : (isdarkmode ? Colors.white : Colors.black)),
      ),
    );
  }
}
