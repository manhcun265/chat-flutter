import 'package:flutter_test/flutter_test.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mocktail/mocktail.dart';
import 'package:flutter/material.dart';

class MockFirebaseAuth extends Mock implements FirebaseAuth {}

class MockUserCredential extends Mock implements UserCredential {}

void main() {
  // Khởi tạo mock FirebaseAuth
  final MockFirebaseAuth mockFirebaseAuth = MockFirebaseAuth();
  final MockUserCredential mockUserCredential = MockUserCredential();

  setUpAll(() {
    // Register mock methods
    registerFallbackValue(mockUserCredential);
  });

  testWidgets('Firebase Auth Test - Successful login', (tester) async {
    // Định nghĩa hành vi mock của Firebase Auth
    when(() => mockFirebaseAuth.signInWithEmailAndPassword(
          email: any(named: 'email'),
          password: any(named: 'password'),
        )).thenAnswer((invocation) async => mockUserCredential);

    // Giả sử bạn có một widget cho việc đăng nhập
    final loginButtonFinder = find.byKey(Key('login_button'));

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ElevatedButton(
            key: Key('login_button'),
            onPressed: () async {
              await mockFirebaseAuth.signInWithEmailAndPassword(
                  email: 'test@example.com', password: 'password123');
            },
            child: Text('Login'),
          ),
        ),
      ),
    );

    // Nhấn vào nút đăng nhập và kiểm tra xem Firebase được gọi
    await tester.tap(loginButtonFinder);
    await tester.pump();

    // Kiểm tra nếu phương thức signInWithEmailAndPassword đã được gọi
    verify(() => mockFirebaseAuth.signInWithEmailAndPassword(
          email: 'test@example.com',
          password: 'password123',
        )).called(1);
  });

  testWidgets('Firebase Auth Test - Failed login', (tester) async {
    // Định nghĩa hành vi mock khi đăng nhập thất bại
    when(() => mockFirebaseAuth.signInWithEmailAndPassword(
          email: any(named: 'email'),
          password: any(named: 'password'),
        )).thenThrow(FirebaseAuthException(code: 'user-not-found'));

    // Giả sử bạn có một widget cho việc đăng nhập
    final loginButtonFinder = find.byKey(Key('login_button'));

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ElevatedButton(
            key: Key('login_button'),
            onPressed: () async {
              try {
                await mockFirebaseAuth.signInWithEmailAndPassword(
                    email: 'wrong@example.com', password: 'wrong123');
              } catch (e) {
                // Kiểm tra lỗi thất bại
                expect(e, isInstanceOf<FirebaseAuthException>());
              }
            },
            child: Text('Login'),
          ),
        ),
      ),
    );

    // Nhấn vào nút đăng nhập và kiểm tra xem có lỗi xảy ra
    await tester.tap(loginButtonFinder);
    await tester.pump();

    // Kiểm tra rằng FirebaseAuthException đã được ném ra
    verify(() => mockFirebaseAuth.signInWithEmailAndPassword(
          email: 'wrong@example.com',
          password: 'wrong123',
        )).called(1);
  });
}
