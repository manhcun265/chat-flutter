import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

// Giả lập Firebase hoặc một dịch vụ gửi tin nhắn.
class MockMessagingService extends Mock {
  Future<void> sendMessage(String message);
  Stream<List<String>> getMessages();
}

void main() {
  group('Messaging functionality tests', () {
    // Khởi tạo mock service
    final MockMessagingService mockMessagingService = MockMessagingService();
    
    // Test gửi tin nhắn thành công
    testWidgets('Send message successfully', (tester) async {
      final messageController = TextEditingController();

      // Giả lập hành vi của service gửi tin nhắn
      when(() => mockMessagingService.sendMessage(any())).thenAnswer((_) async {});

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            appBar: AppBar(title: Text('Messaging Test')),
            body: Column(
              children: [
                TextField(
                  controller: messageController,
                  key: Key('message_field'),
                  decoration: InputDecoration(labelText: 'Enter message'),
                ),
                ElevatedButton(
                  key: Key('send_button'),
                  onPressed: () {
                    mockMessagingService.sendMessage(messageController.text);
                  },
                  child: Text('Send'),
                ),
              ],
            ),
          ),
        ),
      );

      // Nhập tin nhắn vào trường văn bản
      await tester.enterText(find.byKey(Key('message_field')), 'Hello, this is a test message!');
      await tester.pump();

      // Nhấn vào nút gửi tin nhắn
      await tester.tap(find.byKey(Key('send_button')));
      await tester.pump();

      // Kiểm tra xem phương thức sendMessage đã được gọi với đúng tin nhắn
      verify(() => mockMessagingService.sendMessage('Hello, this is a test message!')).called(1);
    });

    // Test hiển thị tin nhắn
    testWidgets('Display sent message', (tester) async {
      // Giả lập stream nhận tin nhắn
      when(() => mockMessagingService.getMessages()).thenAnswer((_) => Stream.value(['Message 1', 'Message 2']));

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            appBar: AppBar(title: Text('Messaging Test')),
            body: StreamBuilder<List<String>>(
              stream: mockMessagingService.getMessages(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                }

                if (snapshot.hasData) {
                  final messages = snapshot.data!;
                  return ListView.builder(
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      return ListTile(title: Text(messages[index]));
                    },
                  );
                } else {
                  return Text('No messages');
                }
              },
            ),
          ),
        ),
      );

      // Xác nhận rằng các tin nhắn từ stream được hiển thị đúng trên giao diện
      await tester.pump();

      // Kiểm tra xem 2 tin nhắn có xuất hiện trên giao diện không
      expect(find.text('Message 1'), findsOneWidget);
      expect(find.text('Message 2'), findsOneWidget);
    });
  });
}
